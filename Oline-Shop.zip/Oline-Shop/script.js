const products = [
    {id: 1 , name: "گوشی موبایل" , price: 93000000 , image: "https://smartestorder.com/cdn/shop/files/1_fef40be4-bffd-47f5-b33e-904f75218a59.png?v=1740931495&width=540"},
    {id: 2 , name: "لپتاپ" , price: 120000000 , image: "https://www.technolife.com/image/small_product-TLP-31145_29f73783-0a86-47bf-a10a-03a127f029ab.png"},
    {id: 3 , name: "موتور سیکلت" , price: 180000000 , image: "https://www.shoppartners.nl/img/medium/schaalmodel-motor-kawasaki-h2-r-ninja-112/10192/420.jpg"},{id: 4 , name: "یخچال" , price: 85000000 , image: "https://alokhanegi.com/wp-content/uploads/2023/09/%DB%8C%D8%AE%DA%86%D8%A7%D9%84-%D9%81%D8%B1%DB%8C%D8%B2%D8%B1-%D8%A7%D9%84-%D8%AC%DB%8C-X267-9.jpg"},
    {id: 5 , name: "تلویزیون" , price: 15000000 , image: "https://www.tcl.ir/wp-content/uploads/2024/09/65P755-tcl-3.png"},
    {id: 6 , name: "ایپد" , price: 110000000 , image: "https://softpple.com/wp-content/uploads/Gray-0-2-600x600.jpg"}
];

const productList = document.querySelector(".product-list");

products.forEach(product => {
    const productElement = document.createElement("div");
    productElement.classList.add("product")

    productElement.innerHTML = `
    <img src = "${product.image}"/>
    <h3>${product.name}</h3>
    <p>${product.price} تومان</p>
    <button onclick = "addToCart(${product.id} )">اضافه به سبد خرید</button>
    `;

    productList.appendChild(productElement)
});

// سبد خرید
const cart = []

// افزودن محصول به سبد خرید

function addToCart(productID){
    const product = products.find(p => p.id === productID)
    const cart = JSON.parse(localStorage.getItem("cart")) || []
    cart.push(product);
    localStorage.setItem("cart" , JSON.stringify(cart));
    alert("محصول به سبد خرید اضافه شد")
};

function updateCart(){
    const cartItems = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");

    cartItems.innerHTML = ``

    cart.forEach(item => {
        const li = document.createElement("li");
        li.textContent = `${item.name} - ${item.price} تومان`
        cartItems.appendChild(li)    

    });

    const total = cart.reduce((sum , item) => sum + item.price, 0)
    totalPrice.textContent = `قیمت کل: ${total} تومان`
}
