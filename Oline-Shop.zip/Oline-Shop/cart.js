function loadCart(){
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartItems = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");

    cartItems.innerHTML = '';

    let total = 0;

    cart.forEach((item , index) => {
        const li = document.createElement("li");
        
        li.innerHTML = `
        ${item.name} - ${item.price} تومان
        <button onclick = "removeItem(${index})"> حذف </button>
        `;
        cartItems.appendChild(li);
        total += item.price
    });

    totalPrice.textContent = `قیمت کل: ${total} تومان`;

}


function removeItem(index){
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index , 1)
    localStorage.setItem("cart" , JSON.stringify(cart));
    loadCart()
};
 
window.addEventListener("DOMContentLoaded" , loadCart)